// src/app/services/turma.service.ts
import { Injectable } from '@angular/core';
import { Turma } from '../models/turma.model';
import { Aluno } from '../models/aluno.model';

@Injectable({ providedIn: 'root' })
export class TurmaService {
  /** média mínima para aprovação */
  private readonly mediaCorte = 7;

  /** "banco" em memória para fins didáticos */
  private turmas: Turma[] = [
    new Turma(1, 'Turma A (Noite)', [
      new Aluno(1, 'Oswaldo',    [8, 7.5, 9]),
      new Aluno(2, 'Gisele',  [6, 6.5, 7]),
      new Aluno(3, 'Giovanna',  [9, 8.5, 10]),
      new Aluno(4, 'Giulianna',  [4, 6, 5.5]),
      new Aluno(5, 'Jujuba', [7, 7, 7]),
      new Aluno(5, 'Pipoca', [7, 3, 8]),
    ])
  ];

  getTurmas(): Turma[] {
    return this.turmas;
  }

  getTurma(id: number): Turma | undefined {
    return this.turmas.find(t => t.id === id);
  }

  /** média aritmética simples das notas do aluno */
  calcularMedia(aluno: Aluno): number {
    if (!aluno.notas.length) return 0;
    const soma = aluno.notas.reduce((acc, n) => acc + n, 0);
    return soma / aluno.notas.length;
  }

  /** aprovado se média >= média de corte (padrão 7) */
  estaAprovado(aluno: Aluno, mediaCorte = this.mediaCorte): boolean {
    return this.calcularMedia(aluno) >= mediaCorte;
  }

  getMediaCorte(): number {
    return this.mediaCorte;
  }
}
