// src/app/pages/home/home.page.ts
import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { CommonModule, NgClass } from '@angular/common';
import { TurmaService } from '../services/turma.service';
import { Turma } from '../models/turma.model';
import { Aluno } from '../models/aluno.model';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [IonicModule, CommonModule, NgClass],
  templateUrl: './home.page.html',
})
export class HomePage {
  turma?: Turma;
  mediaCorte = 0;

  constructor(private turmaService: TurmaService) {}

  ngOnInit() {
    this.turma = this.turmaService.getTurma(1);
    this.mediaCorte = this.turmaService.getMediaCorte();
  }

  media(aluno: Aluno): number {
    return this.turmaService.calcularMedia(aluno);
  }

  aprovado(aluno: Aluno): boolean {
    return this.turmaService.estaAprovado(aluno, this.mediaCorte);
  }
}
