import { AlunoModel } from './aluno.model';

describe('AlunoModel', () => {
  it('should create an instance', () => {
    expect(new AlunoModel()).toBeTruthy();
  });
});
