import { TurmaModel } from './turma.model';

describe('TurmaModel', () => {
  it('should create an instance', () => {
    expect(new TurmaModel()).toBeTruthy();
  });
});
