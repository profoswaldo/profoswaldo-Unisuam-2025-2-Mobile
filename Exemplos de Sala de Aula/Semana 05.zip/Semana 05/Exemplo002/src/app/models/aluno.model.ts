import { Turma } from "./turma.model";

// src/app/models/aluno.model.ts
export class Aluno {
  constructor(
    public id: number,
    public nome: string,
    /** notas do aluno (0..10) */
    public notas: number[]
    
  ) {}
}
