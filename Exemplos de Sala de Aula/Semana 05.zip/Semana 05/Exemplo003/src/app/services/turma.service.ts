// src/app/services/turma.service.ts
import { Injectable } from '@angular/core';
import { Turma } from '../models/turma.model';
import { Aluno } from '../models/aluno.model';
import { AlunoService } from './aluno.service';

@Injectable({ providedIn: 'root' })
export class TurmaService {
  /** critério da turma: média mínima para aprovação */
  private readonly mediaCorte = 7;

  /** "banco" em memória para fins didáticos */
  private turmas: Turma[] = [
    new Turma(1, 'Turma A (Noite)', [
      new Aluno(1, 'Oswaldo',    [8, 7.5, 9]),
      new Aluno(2, 'Gisele',  [6, 6.5, 7]),
      new Aluno(3, 'Giovanna',  [9, 8.5, 10]),
      new Aluno(4, 'Giulianna',  [4, 6, 5.5]),
      new Aluno(5, 'Jujuba', [7, 7, 7]),
      new Aluno(5, 'Pipoca', [7, 3, 8]),
    ])
  ];

  constructor(private alunoService: AlunoService) {}

  getTurmas(): Turma[] {
    return this.turmas;
  }

  getTurma(id: number): Turma | undefined {
    return this.turmas.find(t => t.id === id);
  }

  getMediaCorte(): number {
    return this.mediaCorte;
  }

  /** Regra da turma: aprovado se média >= média de corte da turma */
  estaAprovado(aluno: Aluno): boolean {
    const media = this.alunoService.calcularMedia(aluno);
    return media >= this.mediaCorte;
  }
}
