// src/app/services/aluno.service.ts
import { Injectable } from '@angular/core';
import { Aluno } from '../models/aluno.model';

@Injectable({ providedIn: 'root' })
export class AlunoService {
  /** média aritmética simples das notas do aluno */
  calcularMedia(aluno: Aluno): number {
    if (!aluno.notas.length) return 0;
    const soma = aluno.notas.reduce((acc, n) => acc + n, 0);
    return soma / aluno.notas.length;
  }
}
