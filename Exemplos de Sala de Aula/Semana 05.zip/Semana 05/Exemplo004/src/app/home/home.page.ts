import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { Turma } from '../models/turma.model';
import { Aluno } from '../models/aluno.model';
import { TurmaService } from '../services/turma.service';
import { AlunoService } from '../services/aluno.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [IonicModule, CommonModule],
  templateUrl: './home.page.html',
})
export class HomePage {
  turma?: Turma;
  mediaCorte = 0;

  constructor(
    private turmaService: TurmaService,
    private alunoService: AlunoService
  ) {}

  ngOnInit() {
    this.turma = this.turmaService.getTurma(1);
    this.mediaCorte = this.turmaService.getMediaCorte();
  }

  media(aluno: Aluno): number {
    return this.alunoService.calcularMedia(aluno);
  }

  aprovado(aluno: Aluno): boolean {
    return this.turmaService.estaAprovado(aluno);
  }
}
