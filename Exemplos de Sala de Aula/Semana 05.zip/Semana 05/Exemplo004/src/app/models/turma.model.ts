import { Aluno } from './aluno.model';

export class Turma {
  constructor(
    public id: number,
    public nome: string,
    public alunos: Aluno[]
  ) {}
}
