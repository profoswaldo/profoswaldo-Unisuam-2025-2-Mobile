import { TurmasMock } from './turmas.mock';

describe('TurmasMock', () => {
  it('should create an instance', () => {
    expect(new TurmasMock()).toBeTruthy();
  });
});
