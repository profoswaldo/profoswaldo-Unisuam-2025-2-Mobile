import { Injectable } from '@angular/core';
import { Turma } from '../models/turma.model';
import { Aluno } from '../models/aluno.model';
import { TURMAS_MOCK } from '../data/turmas.mock';
import { AlunoService } from './aluno.service';

@Injectable({ providedIn: 'root' })
export class TurmaService {
  /** critério da turma: média mínima para aprovação */
  private readonly mediaCorte = 7;

  /** fonte de dados (mock) */
  private readonly turmas = TURMAS_MOCK;

  constructor(private alunoService: AlunoService) {}

  getTurmas(): Turma[] {
    return this.turmas;
  }

  getTurma(id: number): Turma | undefined {
    return this.turmas.find(t => t.id === id);
  }

  getMediaCorte(): number {
    return this.mediaCorte;
  }

  /** regra da turma: aprovado se média >= média de corte */
  estaAprovado(aluno: Aluno): boolean {
    return this.alunoService.calcularMedia(aluno) >= this.mediaCorte;
  }
}
