import { AuthMock } from './auth.mock';

describe('AuthMock', () => {
  it('should create an instance', () => {
    expect(new AuthMock()).toBeTruthy();
  });
});
