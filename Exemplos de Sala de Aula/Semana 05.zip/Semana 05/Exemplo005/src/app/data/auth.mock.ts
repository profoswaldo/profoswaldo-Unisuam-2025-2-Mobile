export const AUTH_MOCK = {
  username: 'adm',
  password: '123'
};
