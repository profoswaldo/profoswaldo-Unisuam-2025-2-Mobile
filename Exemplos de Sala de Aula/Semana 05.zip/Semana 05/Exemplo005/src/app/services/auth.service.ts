import { Injectable } from '@angular/core';
import { Credential } from '../models/credential.model';
import { AuthRepository } from '../repositories/auth.repository';

@Injectable({ providedIn: 'root' })
export class AuthService {
  constructor(private repo: AuthRepository) {}

  /** Valida credenciais contra a fonte de dados (mock). */
  validateLogin(cred: Credential): boolean {
    const user = this.repo.getStoredUsername();
    const pass = this.repo.getStoredPassword();
    return cred.username === user && cred.password === pass;
  }
}
