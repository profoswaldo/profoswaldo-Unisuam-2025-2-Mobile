import { CredentialModel } from './credential.model';

describe('CredentialModel', () => {
  it('should create an instance', () => {
    expect(new CredentialModel()).toBeTruthy();
  });
});
