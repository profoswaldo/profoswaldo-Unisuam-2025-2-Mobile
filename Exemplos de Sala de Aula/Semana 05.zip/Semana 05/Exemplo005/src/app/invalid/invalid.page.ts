import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-invalid',
  standalone: true,
  imports: [IonicModule, CommonModule, RouterLink],
  templateUrl: './invalid.page.html'
})
export class InvalidPage {}
