import { Injectable } from '@angular/core';
import { AUTH_MOCK } from '../data/auth.mock';

@Injectable({ providedIn: 'root' })
export class AuthRepository {
  getStoredUsername(): string {
    return AUTH_MOCK.username;
  }

  getStoredPassword(): string {
    return AUTH_MOCK.password;
  }
}
