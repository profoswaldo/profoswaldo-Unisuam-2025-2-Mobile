import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-success',
  standalone: true,
  imports: [IonicModule, CommonModule, RouterLink],
  templateUrl: './success.page.html'
})
export class SuccessPage {}
