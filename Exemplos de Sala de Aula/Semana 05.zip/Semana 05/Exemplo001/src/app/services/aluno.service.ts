// src/app/services/aluno.service.ts
import { Injectable } from '@angular/core';
import { Aluno } from '../models/aluno.model';

@Injectable({ providedIn: 'root' })
export class AlunoService {
  private alunos: Aluno[] = [
    new Aluno(1, 'Pipoca', 'Engenharia'),
    new Aluno(2, 'Oswaldo', 'Computação'),
    new Aluno(3, 'Jujuba', 'Design'),
  ];

  getAlunos(): Aluno[] {
    return this.alunos;
  }

  addAluno(aluno: Aluno): void {
    this.alunos.push(aluno);
  }
}
