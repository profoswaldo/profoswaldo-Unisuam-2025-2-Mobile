// src/app/pages/home/home.page.ts
import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { AlunoService } from '../services/aluno.service';
import { Aluno } from '../models/aluno.model';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [IonicModule, CommonModule],
  templateUrl: './home.page.html',
})
export class HomePage {
  alunos: Aluno[] = [];

  constructor(private alunoService: AlunoService) {}

  ngOnInit() {
    this.alunos = this.alunoService.getAlunos();
  }
}
