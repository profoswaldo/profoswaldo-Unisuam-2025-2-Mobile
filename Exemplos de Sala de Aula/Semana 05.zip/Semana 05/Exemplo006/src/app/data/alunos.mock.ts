import { Aluno } from '../models/aluno.model';

export const ALUNOS_MOCK: Aluno[] = [
  new Aluno(1, 'Giulianna', 'Engenharia'),
  new Aluno(2, 'Oswaldo', 'Computação'),
  new Aluno(3, 'Giovanna', 'Design')
];
