import { AlunosMock } from './alunos.mock';

describe('AlunosMock', () => {
  it('should create an instance', () => {
    expect(new AlunosMock()).toBeTruthy();
  });
});
