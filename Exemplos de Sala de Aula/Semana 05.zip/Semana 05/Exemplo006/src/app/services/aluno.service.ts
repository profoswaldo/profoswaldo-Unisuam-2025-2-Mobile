import { Injectable } from '@angular/core';
import { Aluno } from '../models/aluno.model';
import { AlunoRepository } from '../repositories/aluno.repository';

@Injectable({ providedIn: 'root' })
export class AlunoService {
  constructor(private repo: AlunoRepository) {}

  listar(): Aluno[] {
    return this.repo.list();
  }

  obter(id: number): Aluno | undefined {
    return this.repo.getById(id);
  }

  cadastrar(nome: string, curso: string): Aluno {
    // regra simples: nome e curso obrigatórios
    if (!nome?.trim() || !curso?.trim()) {
      throw new Error('Nome e curso são obrigatórios.');
    }
    return this.repo.create({ nome, curso });
  }

  atualizar(id: number, nome: string, curso: string): boolean {
    return this.repo.update(new Aluno(id, nome, curso));
  }

  remover(id: number): boolean {
    return this.repo.delete(id);
  }
}
