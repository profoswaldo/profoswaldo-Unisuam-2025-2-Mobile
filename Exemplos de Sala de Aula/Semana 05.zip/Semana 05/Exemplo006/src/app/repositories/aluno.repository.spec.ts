import { TestBed } from '@angular/core/testing';

import { AlunoRepository } from './aluno.repository';

describe('AlunoRepository', () => {
  let service: AlunoRepository;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AlunoRepository);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
