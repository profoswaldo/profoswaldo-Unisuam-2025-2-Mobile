import { Injectable } from '@angular/core';
import { Aluno } from '../models/aluno.model';
import { ALUNOS_MOCK } from '../data/alunos.mock';

@Injectable({ providedIn: 'root' })
export class AlunoRepository {
  // cópia para não mutar a constante do mock
  private alunos: Aluno[] = ALUNOS_MOCK.map(a => new Aluno(a.id, a.nome, a.curso));
  private nextId = Math.max(0, ...this.alunos.map(a => a.id)) + 1;

  list(): Aluno[] {
    // retorna cópia para evitar mutações externas
    return this.alunos.map(a => new Aluno(a.id, a.nome, a.curso));
  }

  getById(id: number): Aluno | undefined {
    const a = this.alunos.find(x => x.id === id);
    return a ? new Aluno(a.id, a.nome, a.curso) : undefined;
  }

  create(data: Omit<Aluno, 'id'>): Aluno {
    const novo = new Aluno(this.nextId++, data.nome.trim(), data.curso.trim());
    this.alunos.push(novo);
    return new Aluno(novo.id, novo.nome, novo.curso);
  }

  update(aluno: Aluno): boolean {
    const idx = this.alunos.findIndex(x => x.id === aluno.id);
    if (idx === -1) return false;
    this.alunos[idx] = new Aluno(aluno.id, aluno.nome.trim(), aluno.curso.trim());
    return true;
  }

  delete(id: number): boolean {
    const idx = this.alunos.findIndex(x => x.id === id);
    if (idx === -1) return false;
    this.alunos.splice(idx, 1);
    return true;
  }
}
