import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AlunoService } from '../services/aluno.service';
import { Aluno } from '../models/aluno.model';

@Component({
  selector: 'app-alunos',
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule],
  templateUrl: './alunos.page.html',
})
export class AlunosPage {
  alunos: Aluno[] = [];

  // formulário
  formNome = '';
  formCurso = '';
  editId: number | null = null;

  constructor(private alunoService: AlunoService) {}

  ngOnInit() {
    this.recarregar();
  }

  recarregar() {
    this.alunos = this.alunoService.listar();
  }

  editar(a: Aluno) {
    this.editId = a.id;
    this.formNome = a.nome;
    this.formCurso = a.curso;
  }

  cancelarEdicao() {
    this.editId = null;
    this.formNome = '';
    this.formCurso = '';
  }

  excluir(a: Aluno) {
    if (confirm(`Excluir ${a.nome}?`)) {
      this.alunoService.remover(a.id);
      if (this.editId === a.id) this.cancelarEdicao();
      this.recarregar();
    }
  }

  onSubmit() {
    if (this.editId === null) {
      // CREATE
      this.alunoService.cadastrar(this.formNome, this.formCurso);
    } else {
      // UPDATE
      this.alunoService.atualizar(this.editId, this.formNome, this.formCurso);
    }
    this.cancelarEdicao();
    this.recarregar();
  }
}
