import { Cadeira } from './cadeira';

export class Mesa {
  constructor(
    public numero: number,
    public cadeiras: Cadeira[] = []
  ) {
    // Gera 6 cadeiras por mesa, se não vier preenchido
    if (this.cadeiras.length === 0) {
      for (let i = 1; i <= 6; i++) {
        this.cadeiras.push(new Cadeira(i));
      }
    }
  }

  vagasLivres(): number {
    return this.cadeiras.filter(c => !c.nome.trim()).length;
  }
}
