import { Aluno } from './aluno';

export class AlunoPosgraduacao extends Aluno {
  calcularMedia(): number {
    return this.notaTeste * 0.4 + this.notaProva * 0.6;
  }
}
