import { AlunoPosgraduacao } from './aluno-posgraduacao';

describe('AlunoPosgraduacao', () => {
  it('should create an instance', () => {
    expect(new AlunoPosgraduacao()).toBeTruthy();
  });
});
