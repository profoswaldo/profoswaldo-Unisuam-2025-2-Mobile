export abstract class Aluno {
  constructor(
    public nome: string,
    public notaTeste: number,
    public notaProva: number
  ) {}

  abstract calcularMedia(): number;
}
