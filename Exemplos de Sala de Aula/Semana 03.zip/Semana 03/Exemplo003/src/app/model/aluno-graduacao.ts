import { Aluno } from './aluno';

export class AlunoGraduacao extends Aluno {
  calcularMedia(): number {
    return (this.notaTeste + this.notaProva) / 2;
  }
}
