import { Component } from '@angular/core';
import { IonSelect, IonSelectOption, IonHeader, IonToolbar, IonTitle, IonContent, IonCardTitle, IonCard, IonCardHeader, IonCardContent, IonLabel, IonInput, IonItem, IonButton, IonList, IonListHeader } from '@ionic/angular/standalone';
import { FormsModule } from '@angular/forms';

import { Aluno } from '../model/aluno';
import { AlunoGraduacao } from '../model/aluno-graduacao';
import { AlunoPosgraduacao } from '../model/aluno-posgraduacao';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  imports: [IonListHeader, IonList, IonSelectOption, IonButton, FormsModule, IonItem, IonInput, IonLabel, IonCardContent, IonCardHeader, IonCard, IonCardTitle, 
    IonHeader, IonToolbar, IonTitle, IonContent, IonSelect],
})
export class HomePage {
  titulo = 'Exemplo de Herança';
  tipo = 'graduacao';
  nome = '';
  notaTeste: number | null = null;
  notaProva: number | null = null;

  alunos: Aluno[] = [];

  adicionarAluno() {
    if (!this.nome || this.notaTeste === null || this.notaProva === null) return;

    let novoAluno: Aluno;

    if (this.tipo === 'graduacao') {
      novoAluno = new AlunoGraduacao(this.nome, this.notaTeste, this.notaProva);
    } else {
      novoAluno = new AlunoPosgraduacao(this.nome, this.notaTeste, this.notaProva);
    }

    this.alunos.push(novoAluno);

    // limpar campos
    this.nome = '';
    this.notaTeste = null;
    this.notaProva = null;
  }
}