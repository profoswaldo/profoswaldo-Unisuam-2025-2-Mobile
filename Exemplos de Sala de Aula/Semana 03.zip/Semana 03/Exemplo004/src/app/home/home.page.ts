import { Component } from '@angular/core';
import { IonHeader, IonToolbar, IonTitle, IonContent, IonCard, IonCardHeader, IonCardTitle, IonCardContent } from '@ionic/angular/standalone';
import { AlunoGraduacao } from '../model/aluno-graduacao';
import { Aluno } from '../model/aluno';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  imports: [IonCardContent, IonCardTitle, IonCardHeader, IonCard, IonHeader, IonToolbar, IonTitle, IonContent],
})
export class HomePage {
  alunos: Aluno[] = [
    new AlunoGraduacao('Oswaldo', 20, '2025001', 8, 9),
    new AlunoGraduacao('Gisele', 22, '2025002', 6, 7),
  ];
}