import { Pessoa } from './pessoa';

// Interface "herda" de Pessoa
export interface Aluno extends Pessoa {
  matricula: string;
  calcularMedia(): number;
}
