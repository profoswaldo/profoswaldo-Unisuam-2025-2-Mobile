import { Aluno } from './aluno';

export class AlunoGraduacao implements Aluno {
  constructor(
    public nome: string,
    public idade: number,
    public matricula: string,
    public nota1: number,
    public nota2: number
  ) {}

  apresentar(): string {
    return `Sou ${this.nome}, matrícula ${this.matricula}`;
  }

  calcularMedia(): number {
    return (this.nota1 + this.nota2) / 2;
  }
}
