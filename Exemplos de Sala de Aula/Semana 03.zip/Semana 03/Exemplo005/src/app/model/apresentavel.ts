export interface Apresentavel {
  apresentar(): string; // contrato: todo "Apresentavel" sabe se apresentar
}
