import { Pessoa } from './pessoa';

export class Professor extends Pessoa {
  constructor(nome: string, public siape: string) {
    super(nome);
  }

  papel(): string {
    return 'Professor';
  }
}
