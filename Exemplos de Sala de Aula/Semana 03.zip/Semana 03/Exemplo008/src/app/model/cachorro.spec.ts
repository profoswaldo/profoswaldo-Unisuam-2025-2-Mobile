import { Cachorro } from './cachorro';

describe('Cachorro', () => {
  it('should create an instance', () => {
    expect(new Cachorro()).toBeTruthy();
  });
});
