import { Animal } from "./animal";

// Sobrescreve o método falar()
export class Cachorro extends Animal {
  override falar(): string {
    return `${this.nome} diz: Au au!`;
  }
}
