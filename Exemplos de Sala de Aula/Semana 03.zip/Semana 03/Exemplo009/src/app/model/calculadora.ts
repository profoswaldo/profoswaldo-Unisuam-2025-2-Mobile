export class Calculadora {
  // 🔹 Declarações de sobrecarga (assinaturas)
  somar(a: number, b: number): number;
  somar(a: string, b: string): string;

  // 🔹 Implementação única
  somar(a: any, b: any): any {
    return a + b; // funciona para número e string
  }
}
