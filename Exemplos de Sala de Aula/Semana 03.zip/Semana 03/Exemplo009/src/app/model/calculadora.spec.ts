import { Calculadora } from './calculadora';

describe('Calculadora', () => {
  it('should create an instance', () => {
    expect(new Calculadora()).toBeTruthy();
  });
});
