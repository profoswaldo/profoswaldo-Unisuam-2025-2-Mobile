import { Carro } from './carro';

// Subclasse aproveita o "protected"
export class CarroEsportivo extends Carro {
  constructor(modelo: string, chassi: string) {
    super(modelo, chassi);
  }

  public ativarTurbo(): void {
    this.acelerar(50);
    this.combustivel -= 10; // permitido porque "combustivel" é protected
  }
}
