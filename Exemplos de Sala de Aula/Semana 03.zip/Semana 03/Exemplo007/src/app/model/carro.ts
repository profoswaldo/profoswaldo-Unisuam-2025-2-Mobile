// Classe base demonstrando encapsulamento
export class Carro {
  public modelo: string;               // público
  public readonly chassi: string;      // só leitura
  private _velocidade: number = 0;     // private TS
  #kmRodados: number = 0;              // private JS
  protected combustivel: number = 100; // subclasses acessam

  constructor(modelo: string, chassi: string) {
    this.modelo = modelo;
    this.chassi = chassi;
  }

  public get velocidade(): number {
    return this._velocidade;
  }

  public acelerar(valor: number): void {
    if (valor <= 0) return;
    this._velocidade += valor;
    this.#kmRodados += valor;
    this.consumirCombustivel(valor * 0.5);
  }

  public frear(): void {
    this._velocidade = Math.max(0, this._velocidade - 10);
  }

  public getKmRodados(): number {
    return this.#kmRodados;
  }

  protected consumirCombustivel(qtd: number): void {
    this.combustivel = Math.max(0, this.combustivel - qtd);
  }
}
