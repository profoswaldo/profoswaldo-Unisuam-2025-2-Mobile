import { Component } from '@angular/core';
import { IonHeader, IonToolbar, IonTitle, IonContent, IonCard, IonCardHeader, IonCardTitle, IonCardContent, IonItem, IonLabel, IonInput, IonButton, IonList, IonListHeader } from '@ionic/angular/standalone';
import { FormsModule } from '@angular/forms';

import { Aluno } from '../model/aluno';
import { Endereco } from '../model/endereco';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  imports: [FormsModule, IonListHeader, IonList, IonButton, IonInput, IonLabel, IonItem, IonCardContent, IonCardTitle, IonCardHeader, IonCard, IonHeader, IonToolbar, IonTitle, IonContent],
})
export class HomePage {
  titulo = 'Exemplo de Relacionamento 1:1';
  
  nome = '';
  idade: number | null = null;
  rua = '';
  numero = '';
  cidade = '';

  alunos: Aluno[] = [];

  adicionarAluno() {
    if (!this.nome || this.idade === null || !this.rua || !this.numero || !this.cidade) return;

    const endereco = new Endereco(this.rua, this.numero, this.cidade);
    const aluno = new Aluno(this.nome, this.idade, endereco);

    this.alunos.push(aluno);

    // limpa os campos
    this.nome = '';
    this.idade = null;
    this.rua = '';
    this.numero = '';
    this.cidade = '';
  }
}