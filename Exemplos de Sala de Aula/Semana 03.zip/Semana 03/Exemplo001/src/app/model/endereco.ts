export class Endereco {
  constructor(
    public rua: string,
    public numero: string,
    public cidade: string
  ) {}

  toString(): string {
    return `${this.rua}, ${this.numero} - ${this.cidade}`;
  }
}
