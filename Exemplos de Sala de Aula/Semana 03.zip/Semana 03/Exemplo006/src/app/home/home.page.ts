import { Component } from '@angular/core';
import { IonHeader, IonToolbar, IonTitle, IonContent, IonCard, IonCardHeader, IonCardTitle, IonList, IonLabel, IonItem, IonCardContent, IonInput, IonButton, IonSegmentButton } from '@ionic/angular/standalone';

import { FormsModule } from '@angular/forms';

import { ContaBancaria } from '../model/conta-bancaria';
import { ContaPremium } from '../model/conta-premium';
import { TipoConta } from '../model/tipo-conta'; 

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  imports: [IonSegmentButton, FormsModule, IonButton, IonInput, IonCardContent, IonItem, IonLabel, IonList, IonCardTitle, IonCardHeader, IonCard, IonHeader, IonToolbar, IonTitle, IonContent],
})

//type TipoConta = 'simples' | 'premium';

export class HomePage {
  titulo = 'Encapsulamento em TypeScript (Ionic demo)';

 
  tipo: TipoConta = TipoConta.Simples;

  numeroConta = '0001-9';
  saldoInicial: number | null = 500;

  deposito: number | null = null;
  saque: number | null = null;
  limiteNovo: number | null = null;

  conta: ContaBancaria | null = null;

  criarConta() {
    const num = this.numeroConta.trim() || '0000-0';
    const inicial = Number(this.saldoInicial) || 0;

    this.conta =
      this.tipo === 'premium'
        ? new ContaPremium(num, inicial)
        : new ContaBancaria(num, inicial);

    // só para a UI: limpa campos
    this.deposito = null;
    this.saque = null;
    this.limiteNovo = null;
  }

  aplicarDeposito() {
    if (!this.conta || this.deposito === null) return;
    this.conta.depositar(this.deposito);
    this.deposito = null;
  }

  aplicarSaque() {
    if (!this.conta || this.saque === null) return;
    this.conta.sacar(this.saque);
    this.saque = null;
  }

  aplicarLimite() {
    if (!this.conta || this.limiteNovo === null) return;
    this.conta.limite = this.limiteNovo; // usa setter (com validação)
    this.limiteNovo = null;
  }
}