// Demonstra encapsulamento com private/protected/readonly e getters/setters
export class ContaBancaria {
  // Somente leitura após criação: não pode ser reatribuído
  public readonly numero: string;

  // Campo privado (JavaScript moderno): NINGUÉM acessa fora da classe (nem subclasses)
  // Isso é diferente do "private" do TypeScript, que é checado em tempo de compilação.
  #saldo: number;

  // Campo protegido: subclasses podem ler/alterar
  protected taxaSaque: number = 1.0;

  // Exemplo de private TypeScript + getter/setter com validação
  private _limite: number = 0;

  constructor(numero: string, saldoInicial: number = 0) {
    this.numero = numero;
    this.#saldo = Math.max(0, saldoInicial);
  }

  // Getter "exposição controlada" do saldo (somente leitura no mundo externo)
  get saldo(): number {
    return this.#saldo;
  }

  // Getter/Setter com validação para "limite"
  get limite(): number {
    return this._limite;
  }

  set limite(valor: number) {
    // regra de negócio: limite não pode ser negativo
    this._limite = Math.max(0, Number(valor) || 0);
  }

  // API pública: altera o estado interno de forma controlada
  depositar(valor: number): boolean {
    valor = Number(valor);
    if (!isFinite(valor) || valor <= 0) return false;
    this.#saldo += valor;
    return true;
  }

  sacar(valor: number): boolean {
    valor = Number(valor);
    if (!isFinite(valor) || valor <= 0) return false;

    const total = valor + this.taxaSaque;

    // regra: pode sacar se saldo + limite cobre o total
    if (this.#saldo + this._limite < total) return false;

    // Se não há saldo suficiente, usa parte do limite “descoberto”
    const falta = total - this.#saldo;
    if (falta > 0) {
      // consumir do limite (sem deixar negativo)
      this._limite = Math.max(0, this._limite - falta);
      this.#saldo = 0;
    } else {
      this.#saldo -= total;
    }
    return true;
  }
}
