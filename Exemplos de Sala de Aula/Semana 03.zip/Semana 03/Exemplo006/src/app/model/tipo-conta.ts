export enum TipoConta {
  Simples = 'simples',
  Premium = 'premium'
}
