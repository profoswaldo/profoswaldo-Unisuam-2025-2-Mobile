import { ContaPremium } from './conta-premium';

describe('ContaPremium', () => {
  it('should create an instance', () => {
    expect(new ContaPremium()).toBeTruthy();
  });
});
