import { Nota } from './nota';

export class Aluno {
  constructor(
    public nome: string,
    public notas: Nota[] = []                            // relação 1:N
  ) {}

  adicionarNota(nota: Nota) {
    this.notas.push(nota);
  }

  media(): number {
    if (this.notas.length === 0) return 0;
    const soma = this.notas.reduce((acc, n) => acc + n.valor, 0);
    return Number((soma / this.notas.length).toFixed(2));
  }
}
