import { Nota } from './nota';

describe('Nota', () => {
  it('should create an instance', () => {
    expect(new Nota()).toBeTruthy();
  });
});
