import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms'; //alterei aqui
import { IonHeader, IonToolbar, IonTitle, IonContent, IonLabel, IonCard, IonCardHeader, IonCardTitle, IonItem, IonCardContent, IonInput, IonButton, IonList, IonListHeader } from '@ionic/angular/standalone';

// IMPORTANDO a classe do diretório Model
import { Pessoa } from '../model/pessoa';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  imports: [IonListHeader, IonList, IonButton, FormsModule, IonInput, IonCardContent, IonItem, IonCardTitle, IonCardHeader, IonCard, IonLabel, IonHeader, IonToolbar, IonTitle, IonContent],
})
export class HomePage {
  titulo = 'Exemplo002 - POO';
  nome = '';
  idade: number | null = null;

  pessoas: Pessoa[] = [
    new Pessoa('Pipoca', 2),
    new Pessoa('Jujuba', 7),
  ];

  adicionarPessoa() {
    if (!this.nome || this.idade === null) return;
    this.pessoas.push(new Pessoa(this.nome, this.idade));
    this.nome = '';
    this.idade = null;
  }

  fazerAniversario(p: Pessoa) {
    p.fazerAniversario();
  }
}
