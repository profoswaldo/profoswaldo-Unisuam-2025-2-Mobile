import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

// IMPORTS STANDALONE do Ionic (sem IonicModule)
import {
  IonHeader, IonToolbar, IonTitle, IonContent,
  IonCard, IonCardHeader, IonCardTitle, IonCardContent,
  IonItem, IonLabel, IonInput, IonButton,
  IonList, IonListHeader,
  IonSelect, IonSelectOption
} from '@ionic/angular/standalone';

// Models
import { Aluno } from '../model/aluno';
import { Nota } from '../model/nota';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: true,
  imports: [
    CommonModule, FormsModule,
    IonHeader, IonToolbar, IonTitle, IonContent,
    IonCard, IonCardHeader, IonCardTitle, IonCardContent,
    IonItem, IonLabel, IonInput, IonButton,
    IonList, IonListHeader,
    IonSelect, IonSelectOption
  ],
})
export class HomePage {
  // título
  titulo = 'Relacionamento 1:N – Aluno x Notas';

  // formulário de aluno
  nomeAluno = '';

  // formulário de nota
  valorNota: number | null = null;
  tipoNota: 'teste' | 'prova' | 'trabalho' | 'extra' = 'teste';

  // dados
  alunos: Aluno[] = [];
  alunoSelecionado: Aluno | null = null;

  // ações
  adicionarAluno() {
    const nome = this.nomeAluno.trim();
    if (!nome) return;

    const aluno = new Aluno(nome);
    this.alunos.push(aluno);
    this.alunoSelecionado = aluno; // já seleciona o novo
    this.nomeAluno = '';
  }

  selecionarAluno(a: Aluno) {
    this.alunoSelecionado = a;
  }

  adicionarNota() {
    if (!this.alunoSelecionado || this.valorNota === null) return;

    // clamp 0..10 para evitar valores inválidos
    const v = Math.max(0, Math.min(10, this.valorNota));
    this.alunoSelecionado.adicionarNota(new Nota(v, this.tipoNota));

    // limpar campos
    this.valorNota = null;
    this.tipoNota = 'teste';
  }
}
