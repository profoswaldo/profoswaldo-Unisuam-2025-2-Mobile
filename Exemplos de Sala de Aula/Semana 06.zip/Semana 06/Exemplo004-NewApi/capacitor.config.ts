import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'io.ionic.starter',
  appName: 'Exemplo004-NewApi',
  webDir: 'www'
};

export default config;
