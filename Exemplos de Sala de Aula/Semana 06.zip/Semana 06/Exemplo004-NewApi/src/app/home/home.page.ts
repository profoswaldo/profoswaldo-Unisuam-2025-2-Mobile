import { Component, OnInit } from '@angular/core';
import { CommonModule, NgIf, NgFor } from '@angular/common';
import { FormsModule } from '@angular/forms';

import {
  IonHeader, IonToolbar, IonTitle, IonContent,
  IonList, IonItem, IonLabel, IonThumbnail, IonImg,
  IonButton, IonSpinner, IonSearchbar, IonCard, IonCardHeader, IonCardTitle, IonCardContent
} from '@ionic/angular/standalone';

import { NewsService } from '../services/news.service';

@Component({
  standalone: true,
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
  imports: [
    CommonModule, FormsModule, NgIf, NgFor,
    IonHeader, IonToolbar, IonTitle, IonContent,
    IonList, IonItem, IonLabel, IonThumbnail, IonImg,
    IonButton, IonSpinner, IonSearchbar, IonCard, IonCardHeader, IonCardTitle, IonCardContent
  ],
})
export class HomePage implements OnInit {
  loading = false;
  errorMessage = '';
  articles: any[] = [];
  query = '';

  constructor(private news: NewsService) {}

  ngOnInit(): void {
    this.load();
  }

  load() {
    this.errorMessage = '';
    this.articles = [];
    this.loading = true;

    // 1) tenta top-headlines
    this.news.topHeadlinesBR(this.query).subscribe({
      next: (res) => {
        if (res?.status !== 'ok') {
          // erro de API (NewsAPI manda {status:'error', message:'...'})
          this.fallbackOrError(res?.message);
          return;
        }
        const list = res?.articles ?? [];
        if (list.length > 0) {
          this.articles = list;
          this.loading = false;
        } else {
          // 2) fallback: everything em PT
          this.callFallback();
        }
      },
      error: (err) => {
        console.error('top-headlines error:', err);
        this.fallbackOrError();
      },
    });
  }

  private callFallback() {
    this.news.searchEverythingPT(this.query).subscribe({
      next: (res2) => {
        if (res2?.status !== 'ok') {
          this.loading = false;
          this.errorMessage = res2?.message || 'Falha ao buscar notícias.';
          return;
        }
        this.articles = res2?.articles ?? [];
        this.loading = false;
        if (!this.articles.length) {
          this.errorMessage = 'Nenhuma notícia encontrada.';
        }
      },
      error: (err2) => {
        console.error('everything fallback error:', err2);
        this.loading = false;
        this.errorMessage =
          err2?.status === 401
            ? 'Não autorizado: verifique sua API key do NewsAPI.'
            : err2?.status === 426
            ? 'Seu plano não permite chamadas do browser para este endpoint/domínio.'
            : 'Falha ao buscar notícias. Tente novamente.';
      },
    });
  }

  private fallbackOrError(msg?: string) {
    // Tenta fallback; se também falhar, mostra mensagem
    this.callFallback();
    if (msg) {
      console.warn('NewsAPI status!=ok:', msg);
    }
  }
}
