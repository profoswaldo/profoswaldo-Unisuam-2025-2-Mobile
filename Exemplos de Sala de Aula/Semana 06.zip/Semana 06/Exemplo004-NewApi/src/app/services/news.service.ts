import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class NewsService {
  // Troque pela sua própria API key do NewsAPI
  private readonly apiKey = 'DIGITE AQUI SUA API KEY';

  private readonly topUrl = 'https://newsapi.org/v2/top-headlines';
  private readonly allUrl = 'https://newsapi.org/v2/everything';

  constructor(private http: HttpClient) {}

  /** Top headlines no Brasil (com filtro opcional por termo). */
  topHeadlinesBR(query?: string): Observable<any> {
    const q = query?.trim();
    const url =
      `${this.topUrl}?country=br&pageSize=20` +
      (q ? `&q=${encodeURIComponent(q)}` : '') +
      `&apiKey=${this.apiKey}`;
    return this.http.get(url);
  }

  /** Busca geral em PT (fallback), ordenada por data. Exige termo; uso 'brasil' por padrão. */
  searchEverythingPT(query?: string): Observable<any> {
    const q = encodeURIComponent((query && query.trim()) || 'brasil');
    const url =
      `${this.allUrl}?q=${q}&language=pt&pageSize=20&sortBy=publishedAt&apiKey=${this.apiKey}`;
    return this.http.get(url);
  }
}
