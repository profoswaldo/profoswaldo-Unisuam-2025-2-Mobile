import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', redirectTo: 'cep-consulta', pathMatch: 'full' },
  { path: 'home', loadComponent: () => import('./home/home.page').then(m => m.HomePage) },
  { path: 'cep-consulta', loadComponent: () => import('./cep-consulta/cep-consulta.page').then(m => m.CepConsultaPage) },
];
