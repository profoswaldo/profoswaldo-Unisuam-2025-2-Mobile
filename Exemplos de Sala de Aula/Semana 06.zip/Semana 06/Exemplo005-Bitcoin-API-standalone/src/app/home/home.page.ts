import { Component } from '@angular/core';
import { CommonModule, NgIf, NgFor } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { NewsService } from '../services/news.service';

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule, IonicModule, NgIf, NgFor],
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  selectedCurrency: string = 'Bitcoin';  // Valor padrão
  newsData: any;
  loading: boolean = false;

  constructor(private newsService: NewsService) {}

  fetchNews() {
    if (this.selectedCurrency) {
      this.loading = true;
      this.newsService.getNewsForCurrency(this.selectedCurrency).subscribe(
        (data) => {
          this.newsData = data;
          this.loading = false;
        },
        (err) => {
          console.error('Erro ao buscar as notícias', err);
          this.loading = false;
        }
      );
    }
  }
}
