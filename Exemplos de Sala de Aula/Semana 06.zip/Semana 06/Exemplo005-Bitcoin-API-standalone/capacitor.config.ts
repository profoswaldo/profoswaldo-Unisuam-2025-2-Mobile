import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'io.ionic.starter',
  appName: 'Exemplo005-Bitcoin-API-standalone',
  webDir: 'www'
};

export default config;
