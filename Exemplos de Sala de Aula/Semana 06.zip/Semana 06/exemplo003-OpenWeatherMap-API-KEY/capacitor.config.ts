import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'io.ionic.starter',
  appName: 'exemplo003-OpenWeatherMap-API-KEY',
  webDir: 'www'
};

export default config;
