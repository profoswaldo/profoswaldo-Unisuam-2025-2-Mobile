import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class WeatherService {
  // Sua chave válida do OpenWeatherMap:
  private readonly apiKey = 'DIGITE AQUI SUA APIKEY';
  private readonly apiUrl = 'https://api.openweathermap.org/data/2.5/weather';

  constructor(private http: HttpClient) {}

  getWeather(city: string): Observable<any> {
    const q = encodeURIComponent(city.trim());
    const url = `${this.apiUrl}?q=${q}&appid=${this.apiKey}&units=metric&lang=pt_br`;
    return this.http.get(url);
  }
}
