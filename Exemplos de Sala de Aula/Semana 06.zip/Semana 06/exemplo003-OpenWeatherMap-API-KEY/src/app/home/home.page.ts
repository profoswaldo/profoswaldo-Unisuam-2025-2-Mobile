import { Component } from '@angular/core';
import { CommonModule, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';

// Ionic standalone components
import {
  IonHeader, IonToolbar, IonTitle, IonContent,
  IonItem, IonLabel, IonInput, IonButton,
  IonCard, IonCardContent, IonList
} from '@ionic/angular/standalone';

import { WeatherService } from '../services/weather.service';

@Component({
  standalone: true,
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
  imports: [
    CommonModule, FormsModule, NgIf,
    IonHeader, IonToolbar, IonTitle, IonContent,
    IonItem, IonLabel, IonInput, IonButton,
    IonCard, IonCardContent, IonList
  ],
})
export class HomePage {
  city = '';
  loading = false;
  weatherData: any = null;
  errorMessage = '';

  constructor(private weatherService: WeatherService) {}

  getWeather() {
    this.errorMessage = '';
    this.weatherData = null;

    const c = this.city?.trim();
    if (!c) {
      this.errorMessage = 'Informe uma cidade.';
      return;
    }

    this.loading = true;
    this.weatherService.getWeather(c).subscribe({
      next: (data) => {
        this.weatherData = data;
        this.loading = false;
      },
      error: (err) => {
        console.error(err);
        this.errorMessage =
          err?.status === 401
            ? 'Não autorizado: verifique a chave (e-mail verificado?)'
            : err?.status === 404
            ? 'Cidade não encontrada.'
            : 'Falha ao consultar a API.';
        this.loading = false;
      },
    });
  }
}
