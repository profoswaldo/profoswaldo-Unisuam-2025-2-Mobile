import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule, ToastController } from '@ionic/angular';

import { ProductService } from '../services/product.service';
import { ProductRequest } from '../entities/product-request';
import { ProductResponse } from '../entities/product-response';
import { LoginService } from '../services/login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-products',
  standalone: true,
  imports: [CommonModule, FormsModule, IonicModule],
  templateUrl: './products.page.html',
})
export class ProductsPage {
  productName = '';
  productPrice: number | null = null;
  products: ProductResponse[] = [];

  constructor(
    private productService: ProductService,
    private loginService: LoginService,
    private router: Router,
    private toastCtrl: ToastController
  ) {
    // Mock inicial
    this.refresh();
  }

  async addProduct() {
    if (!this.productName || this.productPrice == null) return;

    const req: ProductRequest = {
      name: this.productName.trim(),
      price: Number(this.productPrice),
    };

    this.productService.addProduct(req);
    this.productName = '';
    this.productPrice = null;
    this.refresh();

    const t = await this.toastCtrl.create({ message: 'Produto adicionado!', duration: 1200 });
    t.present();
  }

  remove(id: number) {
    this.productService.remove(id);
    this.refresh();
  }

  refresh() {
    this.products = this.productService.getAll();
  }

  trackById = (_: number, item: ProductResponse) => item.id;

  logout() {
    this.loginService.logout();
    this.router.navigate(['/login']);
  }
}
