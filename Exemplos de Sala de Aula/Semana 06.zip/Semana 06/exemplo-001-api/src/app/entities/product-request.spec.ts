import { ProductRequest } from './product-request';

describe('ProductRequest', () => {
  it('should create an instance', () => {
    expect(new ProductRequest()).toBeTruthy();
  });
});
