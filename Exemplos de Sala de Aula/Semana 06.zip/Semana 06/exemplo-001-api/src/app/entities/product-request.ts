export interface ProductRequest {
  name: string;
  price: number;
}
