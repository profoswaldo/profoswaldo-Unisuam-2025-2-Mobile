import { ProductResponse } from './product-response';

describe('ProductResponse', () => {
  it('should create an instance', () => {
    expect(new ProductResponse()).toBeTruthy();
  });
});
