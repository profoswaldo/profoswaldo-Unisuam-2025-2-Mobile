import { Injectable } from '@angular/core';
import { Product } from '../entities/product';
import { ProductRequest } from '../entities/product-request';
import { ProductResponse } from '../entities/product-response';

@Injectable({ providedIn: 'root' })
export class ProductService {
  private seq = 3;

  // Mock inicial
  private products: Product[] = [
    { id: 1, name: 'Caderno', price: 15.9, createdAt: new Date() },
    { id: 2, name: 'Caneta',  price: 4.5,  createdAt: new Date() },
    { id: 3, name: 'Mochila', price: 99.0, createdAt: new Date() },
  ];

  addProduct(req: ProductRequest): ProductResponse {
    const entity: Product = {
      id: ++this.seq,
      name: req.name,
      price: req.price,
      createdAt: new Date(),
    };
    this.products.push(entity);
    return this.toResponse(entity);
  }

  getAll(): ProductResponse[] {
    return this.products.map(p => this.toResponse(p));
  }

  remove(id: number): void {
    this.products = this.products.filter(p => p.id !== id);
  }

  // Helpers
  private toResponse(p: Product): ProductResponse {
    return { id: p.id, name: p.name, price: p.price };
  }
}
