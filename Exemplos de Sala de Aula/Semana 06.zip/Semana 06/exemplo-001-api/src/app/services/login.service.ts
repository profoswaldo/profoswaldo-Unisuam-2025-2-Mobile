import { Injectable } from '@angular/core';
import { Login } from '../entities/login';

@Injectable({ providedIn: 'root' })
export class LoginService {
  private readonly TOKEN_KEY = 'demo_token';

  // Mock bem simples: admin/1234
  login(model: Login): boolean {
    const ok = model.username === 'admin' && model.password === '1234';
    if (ok) {
      const fakeToken = 'mock-token-' + Date.now();
      localStorage.setItem(this.TOKEN_KEY, fakeToken);
    }
    return ok;
  }

  logout(): void {
    localStorage.removeItem(this.TOKEN_KEY);
  }

  isAuthenticated(): boolean {
    return !!localStorage.getItem(this.TOKEN_KEY);
  }

  getToken(): string | null {
    return localStorage.getItem(this.TOKEN_KEY);
  }
}
