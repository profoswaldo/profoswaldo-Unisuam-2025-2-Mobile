import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';

import { LoginService } from '../services/login.service';
import { Login } from '../entities/login';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, IonicModule],
  templateUrl: './login.page.html',
})
export class LoginPage {
  model: Login = { username: '', password: '' };
  hint = 'Dica (mock): usuário "admin" e senha "1234".';

  constructor(private loginService: LoginService, private router: Router) {}

  login() {
    const ok = this.loginService.login(this.model);
    if (ok) {
      this.router.navigate(['/products']);
    } else {
      this.hint = 'Credenciais inválidas. Tente "admin" / "1234".';
    }
  }
}
