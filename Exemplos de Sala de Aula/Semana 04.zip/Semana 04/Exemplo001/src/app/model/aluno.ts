import { Endereco } from './endereco';

export class Aluno {
  constructor(
    public nome: string,
    public idade: number,
    public endereco: Endereco   // associação 1:1
  ) {}

  apresentar(): string {
    return `${this.nome}, ${this.idade} anos. Endereço: ${this.endereco.toString()}`;
  }
}
