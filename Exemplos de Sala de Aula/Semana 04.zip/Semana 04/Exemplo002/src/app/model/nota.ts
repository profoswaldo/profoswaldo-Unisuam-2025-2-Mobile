export class Nota {
  constructor(
    public valor: number,                                // 0..10
    public tipo: 'teste' | 'prova' | 'trabalho' | 'extra' = 'teste'
  ) {}
}
