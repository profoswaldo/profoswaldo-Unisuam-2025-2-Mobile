import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  IonHeader, IonToolbar, IonTitle, IonContent,
  IonCard, IonCardHeader, IonCardTitle, IonCardContent,
  IonButton, IonList, IonItem, IonLabel
} from '@ionic/angular/standalone';

import { Calculadora } from '../model/calculadora';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  standalone: true,
  imports: [
    CommonModule,
    IonHeader, IonToolbar, IonTitle, IonContent,
    IonCard, IonCardHeader, IonCardTitle, IonCardContent,
    IonButton, IonList, IonItem, IonLabel
  ],
})
export class HomePage {
  titulo = 'Exemplo de Sobrecarga (Overload)';

  calc = new Calculadora();

  resultadoNumero: number | null = null;
  resultadoTexto: string | null = null;

  somarNumeros() {
    this.resultadoNumero = this.calc.somar(10, 20); // usa overload numérico
  }

  somarTextos() {
    this.resultadoTexto = this.calc.somar('Bom ', 'dia!'); // usa overload string
  }
}
