import { AlunoGraduacao } from './aluno-graduacao';

describe('AlunoGraduacao', () => {
  it('should create an instance', () => {
    expect(new AlunoGraduacao()).toBeTruthy();
  });
});
