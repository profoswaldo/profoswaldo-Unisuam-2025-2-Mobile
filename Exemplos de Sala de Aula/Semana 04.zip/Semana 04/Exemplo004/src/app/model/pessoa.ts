// Interface básica
export interface Pessoa {
  nome: string;
  idade: number;
  apresentar(): string;
}
