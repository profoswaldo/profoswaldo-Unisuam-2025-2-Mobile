import { Carroesportivo } from './carroesportivo';

describe('Carroesportivo', () => {
  it('should create an instance', () => {
    expect(new Carroesportivo()).toBeTruthy();
  });
});
