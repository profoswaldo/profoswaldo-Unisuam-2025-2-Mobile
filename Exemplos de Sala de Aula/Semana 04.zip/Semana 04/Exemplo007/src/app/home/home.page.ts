import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  IonHeader, IonToolbar, IonTitle, IonContent,
  IonCard, IonCardHeader, IonCardTitle, IonCardContent,
  IonButton, IonList, IonItem, IonLabel
} from '@ionic/angular/standalone';

import { Carro } from '../model/carro';
import { CarroEsportivo } from '../model/carroesportivo';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  standalone: true,
  imports: [
    CommonModule,
    IonHeader, IonToolbar, IonTitle, IonContent,
    IonCard, IonCardHeader, IonCardTitle, IonCardContent,
    IonButton, IonList, IonItem, IonLabel
  ],
})
export class HomePage {
  titulo = 'Encapsulamento: public, private, protected, readonly';

  carro = new Carro('Sedan', 'ABC123');
  esportivo = new CarroEsportivo('F1', 'XYZ999');

  acelerarSedan() {
    this.carro.acelerar(20);
  }

  turboEsportivo() {
    this.esportivo.ativarTurbo();
  }
}
