import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

// Ionic standalone
import {
  IonHeader, IonToolbar, IonTitle, IonContent,
  IonCard, IonCardHeader, IonCardTitle, IonCardContent,
  IonButton, IonList, IonItem, IonLabel
} from '@ionic/angular/standalone';

import { Animal } from '../model/animal';
import { Cachorro } from '../model/cachorro';
import { Gato } from '../model/gato';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  standalone: true,
  imports: [
    CommonModule,
    IonHeader, IonToolbar, IonTitle, IonContent,
    IonCard, IonCardHeader, IonCardTitle, IonCardContent,
    IonButton, IonList, IonItem, IonLabel
  ],
})
export class HomePage {
  titulo = 'Exemplo de Sobrescrita (Override)';

  animais: Animal[] = [
    new Animal('Bicho'),
    new Cachorro('Rex'),
    new Gato('Mimi'),
  ];
}
