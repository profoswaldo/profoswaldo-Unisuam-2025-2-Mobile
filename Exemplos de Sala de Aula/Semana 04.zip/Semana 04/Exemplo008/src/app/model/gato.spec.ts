import { Gato } from './gato';

describe('Gato', () => {
  it('should create an instance', () => {
    expect(new Gato()).toBeTruthy();
  });
});
