// Classe base
export class Animal {
  constructor(public nome: string) {}

  falar(): string {
    return `${this.nome} emite um som genérico.`;
  }
}
