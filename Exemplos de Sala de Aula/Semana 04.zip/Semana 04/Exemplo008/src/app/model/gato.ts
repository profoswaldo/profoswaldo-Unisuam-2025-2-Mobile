import { Animal } from './animal';

// Sobrescreve o método falar()
export class Gato extends Animal {
  override falar(): string {
    return `${this.nome} diz: Miau!`;
  }
}
