import { Anima } from './animal';

describe('Anima', () => {
  it('should create an instance', () => {
    expect(new Anima()).toBeTruthy();
  });
});
