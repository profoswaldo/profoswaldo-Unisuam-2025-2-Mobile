import { Component } from '@angular/core';
import { IonHeader, IonToolbar, IonTitle, IonContent, IonCard, IonCardHeader, IonCardTitle, IonCardContent, IonList, IonItem, IonLabel } from '@ionic/angular/standalone';

import { Aluno } from '../model/aluno';
import { Professor } from '../model/professor';
import { Pessoa } from '../model/pessoa'; // tipo base

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  imports: [IonLabel, IonItem, IonList, IonCardContent, IonCardTitle, IonCardHeader, IonCard, IonHeader, IonToolbar, IonTitle, IonContent],
})
export class HomePage {
  titulo = 'POO: Interface + Abstrata + Concretas';

  // Array tipado pela classe abstrata: polimorfismo em ação
  pessoas: Pessoa[] = [
    new Aluno('Maria', '2025A001'),
    new Professor('Paulo', '998877'),
  ];
}
