import { Apresentavel } from './apresentavel';

export abstract class Pessoa implements Apresentavel {
  constructor(public nome: string) {}

  // método "template" comum a todos
  apresentar(): string {
    return `Olá! Sou ${this.nome}, ${this.papel().toLowerCase()}.`;
  }

  // força as subclasses a definirem o papel
  abstract papel(): string;
}
