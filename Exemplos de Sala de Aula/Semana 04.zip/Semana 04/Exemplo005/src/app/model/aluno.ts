import { Pessoa } from './pessoa';

export class Aluno extends Pessoa {
  constructor(nome: string, public matricula: string) {
    super(nome);
  }

  papel(): string {
    return 'Aluno';
  }
}
