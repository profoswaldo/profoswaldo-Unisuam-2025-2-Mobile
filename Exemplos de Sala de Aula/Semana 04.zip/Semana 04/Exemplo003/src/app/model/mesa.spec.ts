import { Mesa } from './mesa';

describe('Mesa', () => {
  it('should create an instance', () => {
    expect(new Mesa()).toBeTruthy();
  });
});
