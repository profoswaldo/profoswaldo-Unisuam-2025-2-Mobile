import { Cadeira } from './cadeira';

describe('Cadeira', () => {
  it('should create an instance', () => {
    expect(new Cadeira()).toBeTruthy();
  });
});
