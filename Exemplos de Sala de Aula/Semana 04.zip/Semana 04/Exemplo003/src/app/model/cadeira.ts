export class Cadeira {
  constructor(
    public numero: number,
    public nome: string = ''   // nome do ocupante
  ) {}
}
