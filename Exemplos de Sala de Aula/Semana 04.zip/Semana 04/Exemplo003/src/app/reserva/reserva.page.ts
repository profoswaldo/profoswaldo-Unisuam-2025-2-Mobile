import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

// Ionic standalone
import {
  IonHeader, IonToolbar, IonTitle, IonContent,
  IonCard, IonCardHeader, IonCardTitle, IonCardContent,
  IonItem, IonLabel, IonInput, IonButton,
  IonList, IonListHeader, IonSelect, IonSelectOption,
  IonGrid, IonRow, IonCol
} from '@ionic/angular/standalone';

import { Mesa } from '../model/mesa';
import { Cadeira } from '../model/cadeira';

@Component({
  selector: 'app-reserva',
  templateUrl: 'reserva.page.html',
  styleUrls: ['reserva.page.scss'],
  standalone: true,
  imports: [
    CommonModule, FormsModule,
    IonHeader, IonToolbar, IonTitle, IonContent,
    IonCard, IonCardHeader, IonCardTitle, IonCardContent,
    IonItem, IonLabel, IonInput, IonButton,
    IonList, IonListHeader, IonSelect, IonSelectOption,
    IonGrid, IonRow, IonCol
  ],
})
export class ReservaPage {
  titulo = 'Reservas para o Show';

  // Teatro com N mesas (ex.: 12). Cada mesa tem 6 cadeiras.
  //mesas: Mesa[] = Array.from({ length: 12 }, (_, i) => new Mesa(i + 1));
  // ou
  /* mesas: Mesa[] = [];

    constructor() {
      for (let i = 1; i <= 12; i++) {
      this.mesas.push(new Mesa(i));
    }
  }*/

  mesas: Mesa[] = [
  new Mesa(1),
  new Mesa(2),
  new Mesa(3),
  new Mesa(4),
  new Mesa(5),
  new Mesa(6),
  new Mesa(7),
  new Mesa(8),
  new Mesa(9),
  new Mesa(10),
  new Mesa(11),
  new Mesa(12),
];


  mesaSelecionada: Mesa | null = null;

  selecionarMesaPorNumero(numero: number) {
    this.mesaSelecionada = this.mesas.find(m => m.numero === Number(numero)) ?? null;
  }

  limparMesa(m: Mesa) {
    m.cadeiras.forEach(c => c.nome = '');
  }

  // Apenas para demonstrar “salvar” (aqui, mantemos em memória)
  salvarReserva() {
    if (!this.mesaSelecionada) return;
    // Aqui você poderia enviar para API, localStorage etc.
    alert(`Mesa ${this.mesaSelecionada.numero} reservada!`);
  }
}
