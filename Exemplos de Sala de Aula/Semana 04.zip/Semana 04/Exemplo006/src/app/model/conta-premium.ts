import { ContaBancaria } from './conta-bancaria';

// Subclasse que aproveita "protected taxaSaque"
// Encapsulamento: a subclasse não enxerga #saldo, mas pode ajustar taxa
export class ContaPremium extends ContaBancaria {
  constructor(numero: string, saldoInicial: number = 0) {
    super(numero, saldoInicial);
    // Premium: saque sem taxa
    this.taxaSaque = 0;
    // E pode já vir com limite inicial (via setter)
    this.limite = 1000;
  }
}
