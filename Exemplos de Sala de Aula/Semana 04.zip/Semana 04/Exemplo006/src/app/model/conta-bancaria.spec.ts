import { ContaBancaria } from './conta-bancaria';

describe('ContaBancaria', () => {
  it('should create an instance', () => {
    expect(new ContaBancaria()).toBeTruthy();
  });
});
