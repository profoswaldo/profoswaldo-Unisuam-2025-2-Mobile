import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: 'home',
    loadComponent: () => import('./home/home.page').then((m) => m.HomePage),
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full',
  },
  {
    path: 'detalhe/:id', //alterei aqui para colocar o parametro da rota
    loadComponent: () => import('./detalhe/detalhe.page').then( m => m.DetalhePage)
  },
];
