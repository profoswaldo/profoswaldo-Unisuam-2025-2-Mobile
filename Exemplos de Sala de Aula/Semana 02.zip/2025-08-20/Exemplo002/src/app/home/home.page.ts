import { Component } from '@angular/core';
import { RouterLink } from '@angular/router'; //alterei aqui
import { IonHeader, IonToolbar, IonTitle, IonContent, IonButton, IonList, IonItem } from '@ionic/angular/standalone'; //alterei aqui colocando IonButton, IonList, IonItem

@Component({
  selector: 'app-home',
  standalone: true, //alterei aqui
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  imports: [IonHeader, IonToolbar, IonTitle, IonContent, 
    IonButton, IonList, IonItem, RouterLink], //alterei aqui colocando IonButton, IonList, IonItem, RouterLink
})
export class HomePage {
  constructor() {}

}
