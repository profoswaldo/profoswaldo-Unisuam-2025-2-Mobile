import { Component, OnInit, inject } from '@angular/core';  //alterei aqui
import { ActivatedRoute, RouterLink } from '@angular/router'; //alterei aqui
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonHeader, IonTitle, IonToolbar, IonContent, IonButton} from '@ionic/angular/standalone'; //alterei aqui colocando IonButton

@Component({
  selector: 'app-detalhe',
  templateUrl: './detalhe.page.html',
  styleUrls: ['./detalhe.page.scss'],
  standalone: true,
  imports: [IonHeader, IonTitle, IonToolbar, CommonModule, FormsModule, IonContent, IonButton, RouterLink]  //alterei aqui colocando IonButton, RouterLink
})
export class DetalhePage implements OnInit {

  //constructor() { }

  ngOnInit() {
  }


  // Lê o parâmetro de rota uma única vez (suficiente para este exemplo)
  private route = inject(ActivatedRoute);
  id = this.route.snapshot.paramMap.get('id');

}
