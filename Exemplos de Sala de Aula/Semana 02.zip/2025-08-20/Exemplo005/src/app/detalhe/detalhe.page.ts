import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonContent, IonHeader, IonTitle, IonToolbar, IonButton } from '@ionic/angular/standalone';

@Component({
  selector: 'app-detalhe',
  templateUrl: './detalhe.page.html',
  styleUrls: ['./detalhe.page.scss'],
  standalone: true,
  imports: [IonContent, IonHeader, IonTitle, IonToolbar, CommonModule, FormsModule,IonButton]
})
export class DetalhePage{

  aluno = history.state?.aluno ?? null;  // lê o objeto vindo da navegação
  origem = history.state?.origem ?? null;

  constructor(private router: Router) {}

  voltar() {
    this.router.navigateByUrl('/home');
  }

}
