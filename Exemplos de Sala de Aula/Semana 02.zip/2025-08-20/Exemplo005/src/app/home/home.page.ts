import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { IonHeader, IonToolbar, IonTitle, IonContent, IonButton  } from '@ionic/angular/standalone';

@Component({
  selector: 'app-home',
  standalone: true,
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  imports: [IonHeader, IonToolbar, IonTitle, IonContent, IonButton ],
})
export class HomePage {
  constructor(private router: Router) {}

  abrirDetalheComState() {
    const aluno = { id: 1, nome: 'Ana', curso: 'ADS' };

    // Passando objeto via "state" (não aparece na URL)
    this.router.navigateByUrl('/detalhe', {
      state: { aluno, origem: 'home' },
      // dica: se quiser não empilhar histórico, use replaceUrl: true
      // replaceUrl: true
    });
  }
}
