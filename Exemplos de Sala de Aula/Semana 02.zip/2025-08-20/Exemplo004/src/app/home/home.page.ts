import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';
import { IonHeader, IonToolbar, IonTitle, IonContent, IonButton } from '@ionic/angular/standalone';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  imports: [IonHeader, IonToolbar, IonTitle, IonContent, IonButton],
})
export class HomePage {
  constructor(private nav: NavController) {}

  irParaPerfil() {
    // Animação/direção de avanço (empurra nova página na pilha)
    this.nav.navigateForward('/perfil');
  }
}
