import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NavController } from '@ionic/angular';
import { IonContent, IonHeader, IonTitle, IonToolbar, IonButton } from '@ionic/angular/standalone';

@Component({
  selector: 'app-perfil',
  templateUrl: './perfil.page.html',
  styleUrls: ['./perfil.page.scss'],
  standalone: true,
  imports: [IonContent, IonHeader, IonTitle, IonToolbar, CommonModule, FormsModule, IonButton]
})
export class PerfilPage {

  constructor(private nav: NavController) {}

  irParaSobre() {
    this.nav.navigateForward('/sobre');
  }

  voltarProgramatico() {
    // Equivalente ao gesto/botão de voltar; volta um passo na pilha
    this.nav.back();
  }

}
