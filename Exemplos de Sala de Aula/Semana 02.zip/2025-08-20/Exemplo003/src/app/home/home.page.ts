import { Component } from '@angular/core';
import { Router } from '@angular/router'; //alterei aqui
import { IonHeader, IonToolbar, IonTitle, IonContent, IonButton } from '@ionic/angular/standalone'; //alterei aqui IonButton

@Component({
  selector: 'app-home',
  standalone: true,
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  imports: [IonHeader, IonToolbar, IonTitle, IonContent, IonButton], //alterei aqui IonButton
})
export class HomePage {
  constructor(private router: Router) {}

  abrirDetalhe(id: number) {
    // Forma 1: usando navigate (mais comum)
    this.router.navigate(['/detalhe', id]);

    // Forma 2: equivalente com navigateByUrl
    // this.router.navigateByUrl(`/detalhe/${id}`);
  }
}
