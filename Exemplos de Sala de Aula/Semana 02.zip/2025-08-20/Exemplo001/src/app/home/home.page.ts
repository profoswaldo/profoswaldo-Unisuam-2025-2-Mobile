import { Component } from '@angular/core';
import { RouterLink } from '@angular/router'; //alterei aqui
import { IonHeader, IonToolbar, IonTitle, IonContent,IonButton  } from '@ionic/angular/standalone';  //alterei aqui

@Component({
  selector: 'app-home',
  standalone: true, // ✅ necessário para loadComponent
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  imports: [IonHeader, IonToolbar, IonTitle, IonContent, IonButton, RouterLink], //alterei aqui
})
export class HomePage {
  constructor() {}
}
