import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { IonHeader, IonToolbar, IonTitle, IonContent, IonButton  } from '@ionic/angular/standalone';

@Component({
  selector: 'app-home',
  standalone: true,
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  imports: [IonHeader, IonToolbar, IonTitle, IonContent, IonButton ],
})
export class HomePage {
  constructor(private router: Router) {}

  salvarENavegar() {
    const aluno = { id: 7, nome: 'Oswaldo', curso: 'ADS' };

    // Salva no navegador (persiste após reload/fechar o app)
    localStorage.setItem('aluno', JSON.stringify(aluno));
    localStorage.setItem('aluno_origem', 'home');

    // Vai para a página de detalhe (sem params na URL)
    this.router.navigateByUrl('/detalhe');
  }

  limparStorage() {
    localStorage.removeItem('aluno');
    localStorage.removeItem('aluno_origem');
  }
}
