import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonContent, IonHeader, IonTitle, IonToolbar, IonButton  } from '@ionic/angular/standalone';

type Aluno = { id: number; nome: string; curso: string }; //breve vai ser tornar uma classe

@Component({
  selector: 'app-detalhe',
  templateUrl: './detalhe.page.html',
  styleUrls: ['./detalhe.page.scss'],
  standalone: true,
  imports: [IonContent, IonHeader, IonTitle, IonToolbar, CommonModule, FormsModule,IonButton]
})
export class DetalhePage{

  // Inicialize as propriedades para evitar erro de "strictPropertyInitialization"
  aluno: Aluno | null = null;
  origem: string | null = null;

  constructor(private router: Router) {
    this.aluno = this.lerAluno();
    this.origem = localStorage.getItem('aluno_origem');
  }

  private lerAluno(): Aluno | null {
    const txt = localStorage.getItem('aluno');
    if (!txt) return null;
    try {
      // Converte e faz uma validação simples
      const obj = JSON.parse(txt) as Partial<Aluno>;
      if (obj && typeof obj.id !== 'undefined' && typeof obj.nome === 'string' && typeof obj.curso === 'string') {
        return { id: Number(obj.id), nome: obj.nome, curso: obj.curso };
      }
      return null;
    } catch {
      return null;
    }
  }

  limparDados() {
    localStorage.removeItem('aluno');
    localStorage.removeItem('aluno_origem');
    this.aluno = null;
    this.origem = null;
  }

  voltar() {
    this.router.navigateByUrl('/home');
  }

}
